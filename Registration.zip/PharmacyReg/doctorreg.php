<?php
$doctorid = $_POST['doctorid'];
$firstname= $_POST['firstname'];
$Dname = $_POST['lastname']; 
$password = $_POST['password']; 
$address = $_POST['address'];
$gender = $_POST['gender'];
$birthdate = $_POST['birthdate'];
$phoneno = $_POST['phoneno'];
$expertise = $_POST['expertise'];
$email = $_POST['email'];
$licenseno = $_POST['licenseno'];
$city = $_POST['city'];
$country = $_POST['country'];
$certificate= $_POST['certificate'];



if (!empty($doctorid) || !empty($firstname) || !empty($Dname) || !empty($password)|| !empty($address) || !empty($gender) || !empty($birthdate)|| !empty($phoneno)|| !empty($expertise )|| !empty($email)|| !empty($licenseno) || !empty($city)|| !empty($country)|| !empty($certificate)) {
 $host = "localhost";
    $dbUsername = "root";
    $dbfirstname = "";
    $dbname = "ssip";
    //create connection
    $conn = new mysqli($host, $dbUsername, $dbfirstname, $dbname);
    if (mysqli_connect_error()) {
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {
     $SELECT = "SELECT doctorid From doctorreg Where doctorid = ? Limit 1";
     $INSERT = "INSERT Into doctorreg (doctorid, firstname,lastname, password, address,gender,birthdate,phoneno,expertise,email,licenseno,city,country,certificate) values('$doctorid','$firstname','$Dname','$password','$address','$gender','$birthdate','$phoneno','$expertise ','$email','$licenseno','$city','$country','$certificate')";
     //Prepare birthdatement
     $stmt = $conn->prepare($SELECT);
     $stmt->bind_param("i", $doctorid);
     $stmt->execute();
     $stmt->bind_result($address);
     $stmt->store_result();
     $rnum = $stmt->num_rows;
     if ($rnum==0) {
      $stmt->close();
      $stmt = $conn->prepare($INSERT);

           
      $stmt->execute();
      echo "New employee inserted sucessfully";
     } else {
      echo "Someone is already registered already register using this id";
     }
     $stmt->close();
     $conn->close();
    }
} else {
 echo "All field are required";
 die();
}
?> 