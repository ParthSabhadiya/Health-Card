<?php
$dsn = "mysql:host=localhost; dbname= ssip";
$db_user="root";
$db_password="";



$sql ="SELECT * FROM history";

$search_result = filterTable($sql);


// function to connect and execute the query
function filterTable($sql)
{
    $connect = mysqli_connect("localhost", "root", "", "ssip");
    $filter_Result = mysqli_query($connect, $sql);
    return $filter_Result;
} 


?>


<!DOCTYPE html>
<html>
<head>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  
  width: 100%;
  border:3px solid black;
 
}

#customers td, #customers th {
  width: 10%;
 
  padding: 7px;
  
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th{
    
 background-color: #007acc;
  text-align: center;
  
  color: black;
 
}

</style>



</head>




<body style="text-align:center;">

    
            <div>
              <!-- <table class="table table-hover" id="customers" border="10"> -->

             <h3><font size="5">Medical History</font>    </h3>

              <table class="table table-bordered" id="customers" border="0" align="center">
              
                
                <tr>
                  <th scope>Date</th>
                  <th scope>Patient Name</th>
                  <th>Doctor name</th>
                  <th>Diesease Type</th>
                  <th>Diesease Name</th>
                  <th>Medication</th>
                   <th>Suggestions</th>
                   
                        
                </tr> </table>
                 <?php while($row = mysqli_fetch_array($search_result)):?>
                  <table class="table table-bordered" id="customers" border="0" align="center">
                <tr>
                  <td><?php  echo $row['date'];?></td>  
                  <td><?php  echo $row['pname'];?></td>        
                  <td><?php  echo $row['dname'];?></td>
                   <td><?php  echo $row['dieseasetype'];?></td>
                  <td><?php  echo $row['disease'];?></td>
                  <td><?php  echo $row['medication'];?></td>
                  <td><?php  echo $row['suggestion'];?></td>
                  
                </tr>
                
                
                        </table>
                    <?php endwhile;?>
              


       </div>
     
</body><br>
