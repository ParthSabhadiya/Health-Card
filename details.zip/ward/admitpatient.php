<?php
$patientid = $_POST['patientid'];
$hospitalid = $_POST['hospitalid']; 
$doctorid = $_POST['doctorid'];
$dateofadmit = $_POST['dateofadmit'];
$roomno = $_POST['roomno'];
$wardno = $_POST['wardno'];
$hdurequire = $_POST['hdurequire'];
$casualty = $_POST['casualty'];
$Fees = $_POST['Fees'];



if (!empty($patientid) || !empty($hospitalid) || !empty($doctorid) || !empty($dateofadmit) || !empty($roomno) || !empty($wardno)|| !empty($hdurequire)|| !empty($casualty)|| !empty($Fees)) {
 $host = "localhost";
    $dbUsername = "root";
    $dbregdate = "";
    $dbname = "ssip";
    //create connection
    $conn = new mysqli($host, $dbUsername, $dbregdate, $dbname);
    if (mysqli_connect_error()) {
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {
     $SELECT = "SELECT patientid From admitpatient Where patientid = ? Limit 1";
     $INSERT = "INSERT Into admitpatient (patientid, hospitalid, doctorid, dateofadmit,roomno,wardno,hdurequire,casualty,Fees) values('$patientid','$hospitalid','$doctorid','$dateofadmit','$roomno','$wardno','$hdurequire','$casualty ','$Fees')";
     //Prepare bdatement
     $stmt = $conn->prepare($SELECT);
     $stmt->bind_param("i", $patientid);
     $stmt->execute();
     $stmt->bind_result($roomno);
     $stmt->store_result();
     $rnum = $stmt->num_rows;
     if ($rnum==0) {
      $stmt->close();
      $stmt = $conn->prepare($INSERT);

           
      $stmt->execute();
      echo "New employee inserted sucessfully";
     } else {
      echo "Someone is already registered already register using this id";
     }
     $stmt->close();
     $conn->close();
    }
} else {
 echo "All field are required";
 die();
}
?> 
?> 