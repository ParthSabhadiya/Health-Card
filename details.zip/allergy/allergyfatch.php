<?php
$dsn = "mysql:host=localhost; dbname=ssip";
$db_user="root";
$db_password="";



$sql ="SELECT * FROM allergy";
$search_result = filterTable($sql);



// function to connect and execute the query
function filterTable($sql)
{
    $connect = mysqli_connect("localhost", "root", "", "ssip");
    $filter_Result = mysqli_query($connect, $sql);
    return $filter_Result;
} 
if(isset($_POST['update']))
{
    $data = getPosts();
  
        
        $updateStmt = $con->prepare('UPDATE test SET fname = :fname, lname = :lname, age = :age WHERE id = :id');
        $updateStmt->execute(array(
                    ':id'=> $data[0],
                    ':fname'=> $data[1],
                    ':lname'=> $data[2],
                    ':age'  => $data[3],
        ));
        
        
        
    
}


?>



<!DOCTYPE html>
<html>
<head>
  <style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 75%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #007acc;
  color: white;
}
</style>
  <title>TEST</title>
  <link rel="stylesheet" href="allergyfatch.css">
</head>

<body>

    <form action="allergyfatch.php" method="post">
    <table id="customers" align="center">
  <thead>
    <tr>
      <th >Registration No</th>
      <th>Full Name</th>
      <th>Allergy Name</th>
      <th>Symptoms</th>
      <th>Medication</th>
      <th>Frequency</th>
      <th>Message</th>
     
    </tr>
    <?php while($row = mysqli_fetch_array($search_result)):?>
      <tbody>
                <tr>
                    <td><?php echo $row['RegistrationNo'];?></td>
                    <td><?php echo $row['FullName'];?></td>
                    <td><?php echo $row['AllergyName'];?></td>
                    <td><?php echo $row['Symptoms'];?></td>
                    <td><?php echo $row['Medication'];?></td>
                    <td><?php echo $row['Frequency'];?></td>
                    <td><?php echo $row['message'];?></td>

                </tr>

                </tbody>
                <?php endwhile;?>
  </thead>
  
</table>

 
</form>
</body>
</html>

