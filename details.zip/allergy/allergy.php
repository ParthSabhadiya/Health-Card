    <?php
$RegistrationNo = $_POST['RegistrationNo'];
$FullName = $_POST['FullName']; 
$AllergyName = $_POST['AllergyName'];
$Symptoms = $_POST['Symptoms'];
$Medication = $_POST['Medication'];
$Frequency = $_POST['Frequency'];
$message = $_POST['message'];


if (!empty($RegistrationNo) || !empty($FullName) || !empty($AllergyName) || !empty($Symptoms) || !empty($Medication) || !empty($Frequency)|| !empty($message)) {
 $host = "localhost";
    $dbUsername = "root";
    $dbregdate = "";
    $dbname = "ssip";
    //create connection
    $conn = new mysqli($host, $dbUsername, $dbregdate, $dbname);
    if (mysqli_connect_error()) {
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {
     $SELECT = "SELECT RegistrationNo From allergy Where RegistrationNo = ? Limit 1";
     $INSERT = "INSERT Into allergy (RegistrationNo, FullName, AllergyName, Symptoms,Medication,Frequency,message) values('$RegistrationNo','$FullName','$AllergyName','$Symptoms','$Medication','$Frequency','$message')";
     //Prepare bdatement
     $stmt = $conn->prepare($SELECT);
     $stmt->bind_param("i", $RegistrationNo);
     $stmt->execute();
     $stmt->bind_result($Medication);
     $stmt->store_result();
     $rnum = $stmt->num_rows;
     if ($rnum==0) {
      $stmt->close();
      $stmt = $conn->prepare($INSERT);

           
      $stmt->execute();
      echo "New employee inserted sucessfully";
     } else {
      echo "Someone is already registered already register using this id";
     }
     $stmt->close();
     $conn->close();
    }
} else {
 echo "All field are required";
 die();
}
?> 